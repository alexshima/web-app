var mongoose = require('mongoose');
var crypto = require('crypto');
var jwt = require('jsonwebtoken');
var uniqueValidator = require('mongoose-unique-validator');


 var secret = 'Dumbledor';





var PostSchema = new mongoose.Schema({
    author: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    coAuthor: {type: String},
    numOfFollowers:{type: Number, default: 0},
    name: {type: String},
    recipename: {type: String},
    image : {type: String},
    description : {type: String},
    ingredients : [{type: String}],
    initialdirections: {type: String},
    detailedtext : [{type: String}],
    detailedimage : [{type: String}],
    upvotes: {type: Number, default: 0},
    favoritesCount: {type: Number, default: 0},
    type : {type: String},
    comments: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Comment' }]
});




PostSchema.methods.addToNumOfFollowers = function() {
    this.numOfFollowers += 1;
    this.save();
};


PostSchema.methods.subOfNumOfFollowers = function() {
    if(this.numOfFollowers > 0) {
        this.numOfFollowers -= 1;
        this.save();
    }
};



PostSchema.methods.updateFavoriteCount = function(user) {

    var post = this;

    return mongoose.model('User').count({favorites: {$in: [post._id]}}).then(function(count){

        post.favoritesCount = count;

        return post.save();
    });
};


PostSchema.methods.upvote = function(cb) {
    this.upvotes += 1;
    this.save(cb);
};

PostSchema.methods.update = function(cb) {

    this.save(cb);
};





mongoose.model('Post', PostSchema);



var UserSchema = new mongoose.Schema({
    username: {type: String, lowercase: true, unique: true, required: [true, "can't be blank"], match: [/^[a-zA-Z0-9]+$/, 'is invalid'], index: true},

    postsImFollowing:[PostSchema],
    myPosts: [PostSchema],
    favorites: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Post' }],
    following: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],
    hash: String,
    salt: String
}, {timestamps: true});

UserSchema.plugin(uniqueValidator, {message: 'is already taken.'});




UserSchema.methods.validPassword = function(password) {
    var hash = crypto.pbkdf2Sync(password, this.salt, 10000, 64, 'sha512').toString('base64');

    return this.hash === hash;
};


UserSchema.methods.setPassword = function(password){
    this.salt = crypto.randomBytes(16).toString('hex');

    this.hash = crypto.pbkdf2Sync(password, this.salt, 10000, 64, 'sha512').toString('base64');
};

UserSchema.methods.generateJWT = function() {
    var today = new Date();
    var exp = new Date(today);
    exp.setDate(today.getDate() + 60);

    return jwt.sign({
        id: this._id,
        username: this.username,
        exp: parseInt(exp.getTime() / 1000),
    }, secret);
};

UserSchema.methods.toAuthJSON = function(){
    return {
        username: this.username,
        token: this.generateJWT()

    };
};


UserSchema.methods.toJSONFor = function(){
    return {
        postsImFollowing: this.postsImFollowing,
    };
};



UserSchema.methods.addToPostsIFollow = function(postar){

    var i;
    for(i =0 ; i<postar.length ; i++) {
            this.postsImFollowing.push(postar[i]);

    }
    return this.save();
};

UserSchema.methods.favorite = function(post1){


    if(this.favorites.indexOf(post1._id) === -1){

        this.favorites.push(post1._id);



    }else if(this.favorites.indexOf(post1._id) !== -1){
        this.favorites.remove( post1._id );

    }


    return this.save();
};

UserSchema.methods.unfavorite = function(id){
    this.favorites.remove( id );
    return this.save();
};

UserSchema.methods.isFavorite = function(id){
    return this.favorites.some(function(favoriteId){
        return favoriteId.toString() === id.toString();
    });
};

UserSchema.methods.follow= function(id){
    if(this.following.indexOf(id) === -1){
        this.following.push(id);
    }

    return this.save();
};


UserSchema.methods.insertPost= function(post){
    var i;
    for(i=0 ; i< this.myPosts.length ; i++ ){
        if(this.myPosts[i]._id.toString() === post._id.toString()){
            this.myPosts.splice(i,1);
        }
    }
        this.myPosts.push(post);


    return this.save();
};

UserSchema.methods.deletePostFromMyPosts= function(post){
    var i;
    for(i=0 ; i< this.myPosts.length ; i++ ){
        if(this.myPosts[i]._id.toString() === post._id.toString()){
            this.myPosts.splice(i,1);
        }
    }



    return this.save();
};


UserSchema.methods.insertPost22= function(post){
    var i;
    for(i=0 ; i< this.myPosts.length ; i++ ){
        if(this.myPosts[i]._id.toString() === post._id.toString()){
            this.myPosts.splice(i,1);
            this.myPosts.push(post);
        }
    }



    return this.save();
};

UserSchema.methods.updateFollowingPosts= function(post){
    var i;
    for(i=0 ; i< this.postsImFollowing.length ; i++ ){
        if(this.postsImFollowing[i]._id.toString() === post._id.toString()){
            this.postsImFollowing.splice(i,1);
            this.postsImFollowing.push(post);
        }
    }



    return this.save();
};


UserSchema.methods.deletePostsFromUserWhoFollow= function(post){
    var i;
    for(i=0 ; i< this.postsImFollowing.length ; i++ ){
        if(this.postsImFollowing[i]._id.toString() === post._id.toString()){
            this.postsImFollowing.splice(i,1);
            // this.postsImFollowing.push(post);
        }
    }



    return this.save();
};

UserSchema.methods.updateFollowingPostsforallusers= function(post){
    var i;
    for(i=0 ; i< this.postsImFollowing.length ; i++ ){
        if(this.postsImFollowing[i]._id.toString() === post._id.toString()){
            this.postsImFollowing.splice(i,1);
            this.postsImFollowing.push(post);
        }
    }



    return this.save();
};


UserSchema.methods.unfollow = function(id){
    this.following.remove(id);
    return this.save();
};

UserSchema.methods.isFollowing = function(id){
    return this.following.some(function(followId){
        return followId.toString() === id.toString();
    });
};

mongoose.model('User', UserSchema);