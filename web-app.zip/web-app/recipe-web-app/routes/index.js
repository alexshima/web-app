var express = require('express');
var mongoose = require('mongoose');
var Post = mongoose.model('Post');
var Comment = mongoose.model('Comment');
var User = mongoose.model('User');
var router = express.Router();
var passport = require('passport');

var jwt = require('express-jwt');
var secret = 'Dumbledor';

var auth = jwt({secret: secret, userProperty: 'payload'});

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Express' });
});

router.get('/posts', function(req, res, next) {
    Post.find(function(err, posts){
        if(err){ return next(err); }

        res.json(posts);
    });
});




router.post('/posts', auth, function(req, res, next) {

    var post = new Post(req.body);
    post.author = req.payload.id;

    if (typeof req.body.ingredients !== 'undefined' ) {
        post.ingredients = [];
        post.ingredients = req.body.ingredients.split("++");
    }
    if (typeof req.body.detailedtext !== 'undefined' ) {

        post.detailedtext = [];
        post.detailedtext = req.body.detailedtext.split("++");
    }
    if (typeof req.body.detailedimage !== 'undefined' ) {

        post.detailedimage = [];
        post.detailedimage = req.body.detailedimage.split("++");
    }


    User.findById(req.payload.id).then(function(user){
        if (!user) { return res.sendStatus(401); }

        if (typeof req.body.coAuthor !== 'undefined' && typeof post.coAuthor !== 'undefined'  ) {

            User.findOne({username : req.body.coAuthor}).
                populate('myPosts').
                exec(function (error,coAuthorPosts) {
                    coAuthorPosts.insertPost(post);

            })
        }

        return user.insertPost(post);

    }).catch(next);


        post.save(function(err, post){
        if(err){ return next(err); }

        res.json(post);
    });
});
router.param('post', function(req, res, next, id) {
    var query = Post.findById(id);

    query.exec(function (err, post){
        if (err) { return next(err); }
        if (!post) { return next(new Error('can\'t find post')); }

        req.post = post;
        return next();
    });
});





// Preload comment objects on routes with ':comment'
router.param('comment', function(req, res, next, id) {
    var query = Comment.findById(id);

    query.exec(function (err, comment){
        if (err) { return next(err); }
        if (!comment) { return next(new Error("can't find comment")); }

        req.comment = comment;
        return next();
    });

});

router.get('/posts/:post', function(req, res, next) {
    req.post.populate('comments author' , function(err, post) {
        if (err) { return next(err); }

        res.json(post);
    });
});


router.put('/posts/:post/favorite', auth, function(req, res, next) {

    var post1 = req.post;
    User.findById(req.payload.id).then(function(user){

        if (!user) { return res.sendStatus(401); }
        if(req.post.author.toString() === user._id.toString()  ){
            return next(new Error("can't like your own posts"));
        }
        return user.favorite(post1).then(function(){
            return req.post.updateFavoriteCount(user).then(function(post){
                User.findOne(req.post.author).
                populate('myPosts').
                exec(function (error, auser) {
                   console.log("auser:" , auser);
                    auser.insertPost22(post);
                });

                User.
                find({}).
                populate('users').
                exec(function(error, users) {
                    for(j = 0 ; j < users.length ; j++){
                        users[j].updateFollowingPostsforallusers(post);
                    }
                });
                return res.json(post);
            });
        });
    }).catch(next);
});


router.put('/posts/:post/follow' ,auth, function(req, res, next) {
console.log("auth in follow:  ", auth);
    User.findById(req.payload.id).then(function(user){

        if (!user) { return res.sendStatus(401); }
        if(req.post.coAuthor!== 'undefined') {
            if (req.post.author.toString() === user._id.toString() || req.post.coAuthor === user.username) {
                return next(new Error("can't follow yourself"));
            }
        }

        if (req.post.author.toString() === user._id.toString() ) {
            return next(new Error("can't follow yourself"));
        }
        User.findById(req.post.author).
            populate('myPosts').
        exec(function (error, userToFollow) {
            for(i = 0; i< userToFollow.myPosts.length ; i++){
                Post.findById( userToFollow.myPosts[i]._id).
                    exec(function (error,postToAddNum) {
                    postToAddNum.addToNumOfFollowers();
                })
            }
        });
        return user.follow(req.post.author);

    }).catch(next);



});

router.put('/posts/:post/unfollow',auth , function(req, res, next) {
    console.log("auth in unfollow:  ", auth);

    User.findById(req.payload.id).then(function(user){
        if (!user) { return res.sendStatus(401); }
        User.findById(req.post.author).
        populate('myPosts').
        exec(function (error, userUnToFollow) {
            console.log("userToFollow:" , userUnToFollow);
            for(i = 0; i< userUnToFollow.myPosts.length ; i++){
                Post.findById( userUnToFollow.myPosts[i]._id).
                exec(function (error,postToSubNum) {
                    console.log("postToSubNum:" , postToSubNum);
                    postToSubNum.subOfNumOfFollowers();
                })
            }
        });
        return user.unfollow(req.post.author);

    }).catch(next);


});
router.put('/posts/:post/edit/delete', auth, function(req, res, next) {
var post1 = req.post;
    User.findById(req.payload.id).then(function(user){
        user.deletePostsFromUserWhoFollow(post1);

        User.
        findOne({username: post1.coAuthor}).
        exec(function(error, coUser) {
            // console.log("coUser:",coUser);
            coUser.deletePostsFromUserWhoFollow(post1);
            coUser.deletePostFromMyPosts(post1);

        });
        User.
        findOne({username: post1.name}).
        exec(function(error, coUser2) {
            console.log("coUser:",coUser2);
            coUser2.deletePostsFromUserWhoFollow(post1);
            coUser2.deletePostFromMyPosts(post1);

        });
        if (!user) { return res.sendStatus(401); }
        user.deletePostFromMyPosts(post1).then(function(){
                User.
                find({}).
                populate('users').
                exec(function(error, users) {
                    for(j = 0 ; j < users.length ; j++){
                        users[j].deletePostsFromUserWhoFollow(post1);
                    }
                });


            Post.remove({ _id: post1._id}, function (err) {
                if (err) return handleError(err);

            });
        });
    }).catch(next);

});


router.put('/posts/:post/edit', auth, function(req, res, next) {




    if (typeof req.body.description !== 'undefined' ) {
        req.post.description = req.body.description;
         }

    if (typeof req.body.recipename !== 'undefined' ) {
        req.post.recipename = req.body.recipename;
    }
    if (typeof req.body.image !== 'undefined' ) {
        req.post.image = req.body.image;
    }
    if (typeof req.body.ingredients !== 'undefined' ) {
        req.post.ingredients = [];
        req.post.ingredients = req.body.ingredients.split("++");
    }
    if (typeof req.body.initialdirections !== 'undefined' ) {
        req.post.initialdirections = req.body.initialdirections;
    }
    if (typeof req.body.detailedtext !== 'undefined' ) {
        req.post.detailedtext = [];
        req.post.detailedtext = req.body.detailedtext.split("++");
    }
    if (typeof req.body.detailedimage !== 'undefined' ) {
        req.post.detailedimage = [];
        req.post.detailedimage = req.body.detailedimage.split("++");
    }
    if (typeof req.body.type !== 'undefined' ) {
        req.post.type = req.body.type;
    }

    User.findById(req.payload.id).then(function(user){
        user.insertPost(req.post);
    });

    req.post.save();

});




router.post('/posts/:post/comments', auth , function(req, res, next) {
    var comment = new Comment(req.body);
    comment.post = req.post;
    comment.author = req.payload.username;

    comment.save(function(err, comment){
        if(err){ return next(err); }

        req.post.comments.push(comment);
        req.post.save(function(err, post) {
            if(err){ return next(err); }

            res.json(comment);
        });
    });
});



// upvote a comment
router.put('/posts/:post/comments/:comment/upvote', auth, function(req, res, next) {
    req.comment.upvote(function(err, comment){
        if (err) { return next(err); }

        res.json(comment);
    });
});



router.post('/users', function(req, res, next){
    if(!req.body.username || !req.body.password){
        return res.status(400).json({message: 'Please fill out all fields'});
    }
    var user = new User();
    user.username = req.body.username;
    user.setPassword(req.body.password);

    user.save(function (err){
        if(err){ return next(err); }

        return res.json({token: user.generateJWT()})
    });
});


router.post('/users/login', function(req, res, next){
    if(!req.body.username || !req.body.password){
        return res.status(400).json({message: 'Please fill out all fields'});
    }

    passport.authenticate('local', function(err, user, info){
        if(err){ return next(err); }

        if(user){
            return res.json({token: user.generateJWT()});
        } else {
            return res.status(401).json(info);
        }
    })(req, res, next);
});

router.get('/user',auth, function(req, res, next){

    User.findById({_id: req.payload.id}).
        populate('following').
        exec(function (error, users) {
        users.postsImFollowing = [];
            for(var i=0 ; i < users.following.length ; i++){
                users.addToPostsIFollow(users.following[i].myPosts);
            }
            if(users.following.length === 0 ){
                users.postsImFollowing = [];
            }
            res.json(users.toJSONFor());
    });
});


module.exports = router;
