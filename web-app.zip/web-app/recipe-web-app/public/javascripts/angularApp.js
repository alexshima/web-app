var myapp =  angular.module('recipeNews', ['ui.router']);

myapp.config([
    '$stateProvider',
    '$urlRouterProvider',
    function($stateProvider, $urlRouterProvider) {

        $stateProvider
            .state('home', {
                url: '/home',
                templateUrl: '/home.html',
                controller: 'MainCtrl',
                resolve: {
                    postPromise: ['posts', function(posts){
                        return posts.getAll();
                    }]
                }
            })
            .state('posts', {
                url: '/posts/{id}',
                templateUrl: '/posts.html',
                controller: 'PostsCtrl',
                resolve: {
                    post: ['$stateParams', 'posts', function($stateParams, posts) {
                        return posts.get($stateParams.id);
                    }]
                }
            })

            .state('editPost', {
                url: '/posts/{id}/edit',
                templateUrl: '/editPost.html',
                controller: 'EditPostCtrl',
                resolve: {
                    post: ['$stateParams', 'posts', function($stateParams, posts) {
                        return posts.get($stateParams.id);
                    }]
                }
            })

            .state('follow', {
                url: '/posts/{id}/follow',
                templateUrl: '/follow.html',
                controller: 'PostsCtrl',
                resolve: {
                    post: ['$stateParams', 'posts', function($stateParams, posts) {
                        return posts.get($stateParams.id);
                    }]
                }
            })
            .state('addRecipe', {
                 url: '/addRecipe',
                templateUrl: '/addRecipe.html',
                controller: 'AddRecipeCtrl'

            })


            .state('user', {
                url: '/user',
                templateUrl: '/user.html',
                controller: 'UserCtrl',
                resolve: {
                    postPromise: ['myPosts', function(myPosts){
                        return myPosts.getFollowedPosts();
                    }]
                }
            })

            .state('/users/login', {
                url: '/users/login',
                templateUrl: '/users/login.html',
                controller: 'AuthCtrl',
                onEnter: ['$state', 'auth', function($state, auth){
                    if(auth.isLoggedIn()){
                        $state.go('home');
                    }
                }]
            })
            .state('users', {
                url: '/users',
                templateUrl: '/users.html',
                controller: 'AuthCtrl',
                onEnter: ['$state', 'auth', function($state, auth){
                    if(auth.isLoggedIn()){
                        $state.go('home');
                    }
                }]
            });

        $urlRouterProvider.otherwise('home');
    }]);

    myapp.factory( 'myPosts', ['$http', 'auth', function($http, auth){
        var my = {
            myPosts: []
        };

        my.getFollowedPosts = function() {
            return $http.get('/user' , {
                headers: {Authorization: 'Bearer '+auth.getToken()}
            }).then(function(data){

                console.log("DATA::", data.data.postsImFollowing);
                angular.copy(data.data.postsImFollowing, my.myPosts);
                for(var j = 0 ; j< data.data.postsImFollowing.length ; j++){
                    if( data.data.postsImFollowing[j] === null){
                        data.data.postsImFollowing.splice(j, 1);
                    }
                }
                // for(var i = 0 ; i< data.data.postsImFollowing.length ; i++){
                //     my.myPosts[i]= data.data.postsImFollowing[i];
                // }



            });
        };
        return my;


}]);
myapp.factory( 'posts', ['$http', 'auth', function($http, auth){


    var o = {
        posts: []
    };

    o.getAll = function() {
        return $http.get('/posts').success(function(data){
            angular.copy(data, o.posts);
        });
    };
    o.create = function(post) {
        return $http.post('/posts', post, {
            headers: {Authorization: 'Bearer '+auth.getToken()}
        }).success(function(data){
            o.posts.push(data);
        });
    };


    o.favorite = function(post) {
        return $http.put('/posts/' + post._id + '/favorite', null, {
            headers: {Authorization: 'Bearer '+auth.getToken()}
        })
            .success(function(data){
                console.log("DATA::", data);

                post.favoritesCount = data.favoritesCount;
        });
    };

    o.followUser = function(post) {
        return $http.put('/posts/' + post._id + '/follow', null, {
            headers: {Authorization: 'Bearer '+auth.getToken()}
        });

    };
    o.UnFollowUser = function(post) {
        return $http.put('/posts/' + post._id + '/unfollow', null, {
            headers: {Authorization: 'Bearer '+auth.getToken()}
        });

    };
    o.deletePost = function(post) {
        return $http.put('/posts/' + post._id + '/edit' + '/delete', null, {
            headers: {Authorization: 'Bearer '+auth.getToken()}
        });

    };
    o.get = function(id) {
        return $http.get('/posts/' + id).then(function(res){
            return res.data;
        });
    };

    o.addComment = function(id, comment) {
        return $http.post('/posts/' + id + '/comments', comment, {
            headers: {Authorization: 'Bearer '+auth.getToken()}
        });
    };

    o.updatePost = function (post, postToUpdate  ) {
        return $http.put('/posts/' + post._id + '/edit' , postToUpdate, {
            headers: {Authorization: 'Bearer '+auth.getToken()}
        });
    };

    o.upvoteComment = function(post, comment) {
        return $http.put('/posts/' + post._id + '/comments/'+ comment._id + '/upvote', null, {
            headers: {Authorization: 'Bearer '+auth.getToken()}
        }).then(function(data){
            comment.upvotes += 1;
        });
    };
    return o;
}]);


myapp.factory('auth', ['$http', '$window', function($http, $window){
        var auth = {
            saveToken: function (token){
                $window.localStorage['recipe-news-token'] = token;
            },
            getToken: function (){
                return $window.localStorage['recipe-news-token'];
            },
            isLoggedIn: function(){
                var token = auth.getToken();

                if(token){
                    var payload = JSON.parse($window.atob(token.split('.')[1]));
                    return payload.exp > Date.now() / 1000;
                } else {
                    return false;
                }
            },
            currentUser: function(){
                if(auth.isLoggedIn()){
                    var token = auth.getToken();
                    var payload = JSON.parse($window.atob(token.split('.')[1]));

                    return payload.username;
                }
            },

            register: function(user){
                return $http.post('/users', user).success(function(data){
                    auth.saveToken(data.token);
                });
            },
            logIn: function(user){
                return $http.post('/users/login', user).success(function(data){
                    auth.saveToken(data.token);
                });
            },
            logOut: function(){
                $window.localStorage.removeItem('recipe-news-token');
            }

        };

        return auth;
    }]);

myapp.controller('MainCtrl', [
    '$scope',
    'posts',
    'auth',
    '$rootScope',
    '$state',
    '$location',
    function($scope, posts, auth, $rootScope, $state, $location){
        $scope.posts = posts.posts;
        $scope.isLoggedIn = auth.isLoggedIn;

        $scope.incrementUpvotes = function(post) {
            posts.favorite(post).then(function(){
                $location.path('/home');
            });
        };
    }]);

myapp.controller('AddRecipeCtrl', [
        '$scope',
        'posts',
        'auth',
        '$state',
        '$timeout',
        function($scope, posts, auth, $state, $timeout){


            $scope.posts = posts.posts;
            $scope.isLoggedIn = auth.isLoggedIn;


            $scope.fieldsFilled = true;
            $scope.addPost = function(){
                if((!$scope.recipename || $scope.recipename === '') ||
                    (!$scope.image || $scope.image === '') ||
                    (!$scope.description || $scope.description === '') ||
                    (!$scope.ingredients || $scope.ingredients === '') ||
                    (!$scope.detailedtext || $scope.detailedtext === '') ||
                    (!$scope.detailedimage || $scope.detailedimage === '') ) {
                    $scope.fieldsFilled = false;
                    return;
                }

                posts.create({
                    coAuthor: $scope.coAuthor,
                    name : auth.currentUser().toString(),
                    recipename: $scope.recipename,
                    image: $scope.image,
                    description: $scope.description,
                    ingredients: $scope.ingredients,
                    initialdirections: $scope.initialdirections,
                    detailedtext: $scope.detailedtext,
                    detailedimage: $scope.detailedimage,
                    type: $scope.type




                });
                $scope.coAuthor = '';
                $scope.image = '';
                $scope.recipename = '';
                $scope.description = '';
                $scope.ingredients = '';
                $scope.directions = '';
                $scope.type = '';
                $scope.detailedtext = '';
                $scope.detailedimage = '';

                $timeout(function(){
                    $state.go('home', {}, { reload: true });
                },200);

            };

            $scope.incrementUpvotes = function(post) {
                posts.favorite(post);
            };
        }]);
myapp.controller('PostsCtrl', [
        '$scope',
        'posts',
        'post',
        'auth',
        function($scope, posts, post, auth){
            $scope.post = post;
            $scope.isLoggedIn = auth.isLoggedIn;

            $scope.followUser = function () {
                posts.followUser(post);
            };

            $scope.UnFollowUser = function () {
                posts.UnFollowUser(post);
            };



            $scope.addComment = function(){
                if($scope.body === '') { return; }
                posts.addComment(post._id, {
                    body: $scope.body,
                    author: 'user'
                }).success(function(comment) {
                    $scope.post.comments.push(comment);
                });
                $scope.body = '';
            };

            $scope.incrementUpvotes = function(comment){
                posts.upvoteComment(post, comment);
            };
        }]);


myapp.controller('UserCtrl', [
        '$scope',
        'posts',
        'myPosts',
        'auth',
        function($scope,posts, myPosts, auth){
            $scope.followedPosts = myPosts.myPosts;
            console.log("currentUser: ", auth.currentUser());
            $scope.incrementUpvotes = function(post) {
                posts.favorite(post);
                };
        }]);



////EDIT POST
myapp.controller('EditPostCtrl', [
        '$scope',
        'posts',
        'post',
        'auth',
        '$location',
        '$state',
        '$timeout',
        function($scope, posts, post, auth, $location, $state,$timeout ){
            $scope.post = post;
            $scope.isLoggedIn = auth.isLoggedIn;

            $scope.canUpdate = function () {
                if($scope.post.coAuthor !== 'undefined') {
                    if (auth.currentUser() === $scope.post.name || auth.currentUser() === $scope.post.coAuthor) {
                        return true;
                    } else {

                        return false;
                    }
                } else  if (auth.currentUser() === $scope.post.name){
                    return true;
                } else {

                    return false;
                }
            };

            $scope.deletePost = function () {
                posts.deletePost(post);
                $timeout(function(){
                    $state.go('home', {}, { reload: true });
                },200);
            };
            $scope.updatePost = function () {

                posts.updatePost(post,
                    {
                        recipename : $scope.recipename,
                        image : $scope.image,
                        description : $scope.description,
                        ingredients : $scope.ingredients,
                        initialdirections : $scope.initialdirections,
                        detailedtext: $scope.detailedtext,
                        detailedimage: $scope.detailedimage,
                        type : $scope.type

                    });
                $scope.recipename = '';
                $scope.image = '';
                $scope.description = '';
                $scope.ingredients = '';
                $scope.type = '';
                $scope.detailedtext = '';
                $scope.detailedimage = '';

                $timeout(function(){
                    $state.go('home', {}, { reload: true });
                },200);
            };
        }]);

myapp.controller('AuthCtrl', [
        '$scope',
        '$state',
        'auth',
        function($scope, $state, auth){
            $scope.user = {};

            $scope.register = function(){
                auth.register($scope.user).error(function(error){
                    $scope.error = 'UserName Or Password Already exists!!';
                }).then(function(){
                    $state.go('home');
                });
            };

            $scope.logIn = function(){
                auth.logIn($scope.user).error(function(error){
                    $scope.error = error;
                }).then(function(){
                    $state.go('home');
                });
            };

        }]);


myapp.controller('NavCtrl', [
        '$scope',
        'auth',
        function($scope, auth){
            $scope.isLoggedIn = auth.isLoggedIn;
            $scope.currentUser = auth.currentUser;
            $scope.logOut = auth.logOut;
        }]);